
![cv](images/cv.png)

< img src="/images/cv.png" />
        
🧑‍🔬 As a **HCI Researcher**, he pays attention to the combination of technology and user experience, interested in *Multi-modal Natural Human-computer Interaction* and *Human-AI Co-creation*. He has submitted and published in the HCI Journal (*TOCHI*, *IJHCS*, *IJHCI*) and the HCI Conference (*CHI*, *Ubicomp*, *VR*).

🧑‍🎨 As an **IxD Designer**, he pays attention to the product improvement by the optimization of service procedure and user experience. He has interned as a User Experience Designer in *Tencent Group*, *Alibaba Group*, and *TikTok Group*, and won the iF Award and Red Dot Award.

📮 Contact: hongbozhang@zju.edu.cn, hongbooo@outlook.com
